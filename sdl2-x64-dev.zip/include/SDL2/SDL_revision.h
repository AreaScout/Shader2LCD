/* #undef SDL_VENDOR_INFO */
#define SDL_REVISION_NUMBER 0

#ifdef SDL_VENDOR_INFO
#define SDL_REVISION "SDL-release-2.26.2-0-gf070c83a6 (" SDL_VENDOR_INFO ")"
#else
#define SDL_REVISION "SDL-release-2.26.2-0-gf070c83a6"
#endif
